"""The assistant agent: the AI reads the conversation, chooses a tool, reads the result and goes on until
it can answer. This is the "ReAct agent" pattern (reason, act, repeat).

    interviewer's message -> agent (AI) --needs a tool?--> tool -> agent (AI) -> ... -> answer

Where the tools come from:
    MCP_SERVERS      the MCP servers; MultiServerMCPClient starts them and collects their tools
    HIDDEN_TOOLS     MCP tools the AI must not get (it could post without a person's Yes)
    LOCAL_TOOLS      two tools written here: they only ASK for an approval or a post

The one fixed rule: the AI cannot approve a job or post it (to the blog or to Telegram). It can only ask. The interviewer
answers Yes or No on the screen, and then the backend code does it (assistant_service.confirm_action).
"""
import asyncio
import logging
import os
import sys

from langchain_core.tools import tool
from langchain_mcp_adapters.client import MultiServerMCPClient
from langgraph.prebuilt import create_react_agent
from sqlmodel import Session

from app.core import config
from app.core.database import engine
from app.features.assistant.models import AssistantAction
from app.features.jobs.models import Job
from app.graphs.assistant_prompts import ASSISTANT_PROMPT

log = logging.getLogger("assistant")

BACKEND_DIR = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
TIMEOUT_SEC = 180
MAX_STEPS = 16                   # how many AI and tool steps one message may take


def mcp_servers() -> dict:
    """The MCP servers the assistant can use. Each one is a small program started over stdio."""
    environment = {**os.environ, "PYTHONPATH": BACKEND_DIR}       # same settings as the backend; can import `app`
    return {
        "recruitment": {
            "command": sys.executable,
            "args": ["-m", "app.mcp_servers.recruitment_server"],
            "transport": "stdio",
            "env": environment,
        },
        "blogger": {
            "command": sys.executable,
            "args": ["-m", "app.mcp_servers.blogger_server"],
            "transport": "stdio",
            "env": environment,
        },
        "telegram": {
            "command": sys.executable,
            "args": ["-m", "app.mcp_servers.telegram_server"],
            "transport": "stdio",
            "env": environment,
        },
    }


# The Blogger and Telegram servers can post. The assistant only gets their check tools; posting goes through
# request_job_post, which only asks.
HIDDEN_TOOLS = {"publish_blog_post", "send_channel_post"}


# ---------- the two tools that only ask ----------

def _ask(kind: str, job_id: int, text: str = "", apply_url: str = "") -> str:
    with Session(engine) as session:
        job = session.get(Job, job_id)
        if not job:
            return f"Job {job_id} was not found. Use list_jobs to see the saved jobs."
        if kind == "approve_job":
            if job.status == "approved":
                return f"Job {job_id} is already approved."
            if not (job.description or "").strip():
                return "The job has no description yet, so it cannot be approved."
        else:
            if job.status != "approved":
                return "The job is not approved yet. Ask for the approval first (request_job_approval)."
            if not apply_url.strip().startswith("https://") or " " in apply_url.strip():
                return "The application form link is missing or not a link. Ask the interviewer for it (https://...)."
            if not 20 <= len(text.strip()) <= 3500:
                return "The post text must have 20 to 3500 characters."
        action = AssistantAction(kind=kind, job_id=job.id, job_title=job.title, text=text.strip(), apply_url=apply_url.strip())
        session.add(action)
        session.commit()
    return ("The interviewer now sees a Yes / No question on the screen. Nothing has happened yet. "
            "Tell them you are waiting for their answer and stop.")


@tool
def request_job_approval(job_id: int) -> str:
    """Ask the interviewer to approve a saved job. This does NOT approve it: they answer Yes or No on the screen."""
    return _ask("approve_job", job_id)


@tool
def request_job_post(job_id: int, text: str, apply_url: str) -> str:
    """Ask the interviewer to post an approved job (on the company blog or channel). This does NOT post it: they
    answer Yes or No on the screen. text is the post (from prepare_job_post); apply_url is the application form link."""
    return _ask("post_job", job_id, text, apply_url)


LOCAL_TOOLS = [request_job_approval, request_job_post]


# ---------- the AI model ----------

def chat_model():
    if config.LLM_PROVIDER == "fake":
        from app.ai.fake_chat_model import FakeToolChatModel
        return FakeToolChatModel()
    from langchain_google_genai import ChatGoogleGenerativeAI
    return ChatGoogleGenerativeAI(model=config.LLM_MODEL, google_api_key=config.LLM_API_KEY)


# ---------- running it ----------

def _text(content) -> str:
    """The AI's answer as plain text (some models answer with a list of parts)."""
    if isinstance(content, list):
        return " ".join(part.get("text", "") for part in content if isinstance(part, dict)).strip()
    return str(content or "").strip()


async def _run(messages: list[dict]) -> dict:
    client = MultiServerMCPClient(mcp_servers())
    mcp_tools = [t for t in await client.get_tools() if t.name not in HIDDEN_TOOLS]
    # create_react_agent is the helper from the course. Newer LangGraph versions print a note that it moved;
    # it still works the same way.
    agent = create_react_agent(chat_model(), mcp_tools + LOCAL_TOOLS, prompt=ASSISTANT_PROMPT)
    result = await asyncio.wait_for(agent.ainvoke({"messages": messages}, {"recursion_limit": MAX_STEPS}), TIMEOUT_SEC)
    new = result["messages"][len(messages):]                      # what the agent added in this turn
    used = [call["name"] for message in new for call in (getattr(message, "tool_calls", None) or [])]
    return {"answer": _text(new[-1].content) if new else "", "tools": used, "error": ""}


def _plain_reason(problem: Exception) -> str:
    text, name = str(problem), type(problem).__name__
    if "429" in text or "RESOURCE_EXHAUSTED" in text:
        return "the AI service limit is reached (too many requests). Wait a little and try again"
    if "API key" in text or "API_KEY" in text or "401" in text or "403" in text:
        return "the AI service rejected the API key (check LLM_API_KEY in .env)"
    if name == "GraphRecursionError":
        return "the assistant needed too many steps. Ask for one thing at a time"
    return f"{name} while the assistant was working (see the backend log)"


def run_assistant(messages: list[dict]) -> dict:
    """Runs the agent for one conversation. messages = [{"role": "user" | "assistant", "content": "..."}].
    Returns {"answer", "tools", "error"}. Never raises."""
    if config.LLM_PROVIDER != "fake" and not config.LLM_API_KEY:
        return {"answer": "", "tools": [], "error": "LLM_API_KEY is not set in .env"}
    try:
        return asyncio.run(_run(messages))
    except asyncio.TimeoutError:
        return {"answer": "", "tools": [], "error": "the assistant took too long to answer. Try again"}
    except Exception as problem:                      # never str(problem) to the screen: it can hold a key
        log.exception("assistant run failed")
        return {"answer": "", "tools": [], "error": _plain_reason(problem)}
