"""Assistant logic."""
