"""Authentication feature."""
