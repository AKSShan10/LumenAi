"""Company document logic."""
